# Liquid Glass Effect

Жидкое стекло для любого сайта: настоящее преломление всего, что лежит за элементом, блики, радужная дисперсия, матовость и пружинящее растяжение.
Репозиторий сделан для **Claude Code**: он подключает эффект, **но только после того, как ты назовёшь все 7 настроек**.

*Liquid Glass for any website — real refraction of whatever is behind the element. Made for Claude Code: it will not build anything until you give it all 7 settings.*

## Настройки (каждая от 0 до 100)

| Настройка | Что делает |
|---|---|
| **Light** | блики и светлая кромка стекла |
| **Refraction** | насколько сильно стекло искажает то, что за ним |
| **Depth** | толщина линзы по краю и глубина тени |
| **Dispersion** | радужное разделение цветов на краях |
| **Frost** | матовость: размытие и лёгкая дымка |
| **Splay** | как далеко вглубь от края растекается искажение |
| **Strain** | насколько стекло тянется за пальцем/мышью и пружинит назад |

## Как пользоваться с Claude Code

1. Положи в свой проект файлы `CLAUDE.md` и папку `.claude/` из этого репозитория.
2. Скажи Claude Code: «сделай жидкое стекло на кнопках».
3. Он спросит все настройки, которых ты не назвал, и **ничего не будет делать, пока не получит все семь чисел**.
   Быстрее всего подобрать числа в `demo/index.html`: двигай ползунки и нажми «Скопировать настройки для Claude Code».
4. Напиши ему, например: `Light 70, Refraction 60, Depth 50, Dispersion 20, Frost 10, Splay 30, Strain 50`.
5. Он подключит `src/liquid-glass.js` и применит стекло с твоими числами.

## Без Claude Code

```html
<script src="src/liquid-glass.js"></script>
<script>
  LiquidGlass.apply('.card', {
    light: 70, refraction: 60, depth: 50, dispersion: 20, frost: 10, splay: 30, strain: 50
  });
</script>
```

Нужны все 7 настроек: если какой-то нет или число вне 0–100, библиотека бросит ошибку.
Менять потом: `const g = LiquidGlass.apply('.card', {...}); g.update({ frost: 40 });`
Элементу нужен `border-radius`, а за ним — что преломлять (фон, картинка, текст).

## Браузеры

- **Chrome, Edge, Opera, Android Chrome:** полная рефракция (SVG-фильтр в `backdrop-filter`).
- **Safari, Firefox:** честного преломления нет, будет матовое стекло с бликами.

## Файлы

- `src/liquid-glass.js` — сама библиотека, без зависимостей.
- `demo/index.html` — демо с ползунками и кнопкой «Скопировать настройки».
- `CLAUDE.md` и `.claude/skills/liquid-glass/SKILL.md` — правила для Claude Code.

Лицензия MIT.
