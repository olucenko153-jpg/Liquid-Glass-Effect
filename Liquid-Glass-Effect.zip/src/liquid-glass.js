/*! Liquid Glass Effect — MIT License. Real refraction of whatever is behind the element. */
(function (root) {
  'use strict';

  var KEYS = ['light', 'refraction', 'depth', 'dispersion', 'frost', 'splay', 'strain'];
  var NAMES = { light: 'Light', refraction: 'Refraction', depth: 'Depth', dispersion: 'Dispersion', frost: 'Frost', splay: 'Splay', strain: 'Strain' };
  var NS = 'http://www.w3.org/2000/svg';
  var uid = 0, svgRoot = null;

  /* ---------- настройки: нужны ВСЕ семь, каждая от 0 до 100 ---------- */
  function normalize(s) {
    var o = {};
    if (!s || typeof s !== 'object') s = {};
    Object.keys(s).forEach(function (k) { o[String(k).toLowerCase()] = s[k]; });
    return o;
  }
  function validate(s) {
    s = normalize(s);
    var missing = KEYS.filter(function (k) { return typeof s[k] !== 'number' || isNaN(s[k]); });
    if (missing.length) {
      throw new Error('LiquidGlass: не заданы настройки: ' + missing.map(function (k) { return NAMES[k]; }).join(', ') +
        '. Нужны все 7 (' + KEYS.map(function (k) { return NAMES[k]; }).join(', ') + '), каждая число от 0 до 100.');
    }
    KEYS.forEach(function (k) {
      if (s[k] < 0 || s[k] > 100) throw new Error('LiquidGlass: ' + NAMES[k] + ' должна быть от 0 до 100, сейчас ' + s[k] + '.');
    });
    var out = {};
    KEYS.forEach(function (k) { out[k] = s[k]; });
    return out;
  }

  function isChromium() {            // Chrome, Edge, Opera, Android Chrome: backdrop-filter умеет url(#svg)
    return /Chrome\/|Chromium\//.test(navigator.userAgent || '');
  }

  function getSvg() {
    if (svgRoot && document.body.contains(svgRoot)) return svgRoot;
    svgRoot = document.createElementNS(NS, 'svg');
    svgRoot.setAttribute('width', '0'); svgRoot.setAttribute('height', '0');
    svgRoot.setAttribute('aria-hidden', 'true');
    svgRoot.style.cssText = 'position:absolute;width:0;height:0;pointer-events:none';
    svgRoot.appendChild(document.createElementNS(NS, 'defs'));
    document.body.appendChild(svgRoot);
    return svgRoot;
  }

  /* ---------- карта смещения (рефракция по краю стекла) ---------- */
  function sdRoundBox(px, py, hx, hy, r) {
    var qx = Math.abs(px) - hx + r, qy = Math.abs(py) - hy + r;
    var ox = Math.max(qx, 0), oy = Math.max(qy, 0);
    return Math.sqrt(ox * ox + oy * oy) + Math.min(Math.max(qx, qy), 0) - r;
  }
  function makeMap(w, h, radius, depth, splay) {
    var k = Math.min(1, 320 / Math.max(w, h));
    var mw = Math.max(2, Math.round(w * k)), mh = Math.max(2, Math.round(h * k));
    var half = Math.min(mw, mh) / 2;
    var bezel = Math.max(2, Math.min(half, (depth / 100) * half));
    var p = 3 - 2.2 * (splay / 100);                // Splay: 0 — всё у края, 100 — растекается вглубь
    var r = Math.min(radius * k, half);
    var c = document.createElement('canvas'); c.width = mw; c.height = mh;
    var ctx = c.getContext('2d'), img = ctx.createImageData(mw, mh), d = img.data;
    var hx = mw / 2, hy = mh / 2, e = 0.5;
    for (var y = 0; y < mh; y++) {
      for (var x = 0; x < mw; x++) {
        var px = x + 0.5 - hx, py = y + 0.5 - hy, i = (y * mw + x) * 4;
        var sd = sdRoundBox(px, py, hx, hy, r), inside = -sd, vx = 0, vy = 0;
        if (inside > 0 && inside < bezel) {
          var gx = sdRoundBox(px + e, py, hx, hy, r) - sdRoundBox(px - e, py, hx, hy, r);
          var gy = sdRoundBox(px, py + e, hx, hy, r) - sdRoundBox(px, py - e, hx, hy, r);
          var gl = Math.sqrt(gx * gx + gy * gy) || 1;
          var m = Math.pow(1 - inside / bezel, p);
          vx = -(gx / gl) * m; vy = -(gy / gl) * m;      // внутрь стекла
        }
        d[i] = 128 + vx * 127; d[i + 1] = 128 + vy * 127; d[i + 2] = 128; d[i + 3] = 255;
      }
    }
    ctx.putImageData(img, 0, 0);
    return c.toDataURL('image/png');
  }

  function mk(tag, attrs) {
    var el = document.createElementNS(NS, tag);
    for (var a in attrs) el.setAttribute(a, attrs[a]);
    return el;
  }
  function channel(src, scale, matrix, result) {
    return [
      mk('feDisplacementMap', { 'in': 'SourceGraphic', in2: 'map', scale: scale, xChannelSelector: 'R', yChannelSelector: 'G', result: result + 'd' }),
      mk('feColorMatrix', { 'in': result + 'd', type: 'matrix', values: matrix, result: result })
    ];
  }

  /* ---------- один элемент ---------- */
  function Glass(el, settings) {
    this.el = el;
    this.id = 'lg-' + (++uid);
    this.s = validate(settings);
    this.chromium = isChromium();
    this.filter = null;
    this.st = null;
    var self = this;
    this.render();
    if (window.ResizeObserver) {
      var raf = 0;
      this.ro = new ResizeObserver(function () { cancelAnimationFrame(raf); raf = requestAnimationFrame(function () { self.render(); }); });
      this.ro.observe(el);
    }
    this.bindStrain();
  }
  Glass.prototype.update = function (partial) {
    var merged = Object.assign({}, this.s, normalize(partial));
    this.s = validate(merged);
    this.render();
  };
  Glass.prototype.destroy = function () {
    if (this.ro) this.ro.disconnect();
    if (this.filter && this.filter.parentNode) this.filter.parentNode.removeChild(this.filter);
    var st = this.el.style;
    st.backdropFilter = st.webkitBackdropFilter = st.boxShadow = st.background = '';
  };
  Glass.prototype.render = function () {
    var el = this.el, s = this.s, cs = getComputedStyle(el), r = el.getBoundingClientRect();
    var w = Math.round(el.offsetWidth || r.width), h = Math.round(el.offsetHeight || r.height);
    if (!w || !h) return;
    var radius = parseFloat(cs.borderTopLeftRadius) || 0;
    var L = s.light / 100, D = s.depth / 100, F = s.frost / 100;
    var blur = F * 14, sat = 1 + 0.25 * (s.refraction / 100);

    if (this.chromium) {
      var scale = (s.refraction / 100) * 140, disp = s.dispersion / 100;
      var f = mk('filter', { id: this.id, x: 0, y: 0, width: w, height: h, filterUnits: 'userSpaceOnUse', 'color-interpolation-filters': 'sRGB' });
      f.appendChild(mk('feImage', { href: makeMap(w, h, radius, s.depth, s.splay), x: 0, y: 0, width: w, height: h, preserveAspectRatio: 'none', result: 'map' }));
      if (disp > 0.001) {
        var parts = []
          .concat(channel('SourceGraphic', scale * (1 + disp * 0.35), '1 0 0 0 0  0 0 0 0 0  0 0 0 0 0  0 0 0 1 0', 'cr'))
          .concat(channel('SourceGraphic', scale, '0 0 0 0 0  0 1 0 0 0  0 0 0 0 0  0 0 0 1 0', 'cg'))
          .concat(channel('SourceGraphic', scale * (1 - disp * 0.35), '0 0 0 0 0  0 0 0 0 0  0 0 1 0 0  0 0 0 1 0', 'cb'));
        parts.forEach(function (n) { f.appendChild(n); });
        f.appendChild(mk('feBlend', { 'in': 'cr', in2: 'cg', mode: 'screen', result: 'rg' }));
        f.appendChild(mk('feBlend', { 'in': 'rg', in2: 'cb', mode: 'screen', result: 'out' }));
      } else {
        f.appendChild(mk('feDisplacementMap', { 'in': 'SourceGraphic', in2: 'map', scale: scale, xChannelSelector: 'R', yChannelSelector: 'G', result: 'out' }));
      }
      f.appendChild(mk('feGaussianBlur', { 'in': 'out', stdDeviation: blur.toFixed(2) }));
      var defs = getSvg().firstChild;
      if (this.filter && this.filter.parentNode) defs.removeChild(this.filter);
      defs.appendChild(f); this.filter = f;
      var bf = 'url(#' + this.id + ') saturate(' + sat.toFixed(2) + ')';
      el.style.backdropFilter = bf; el.style.webkitBackdropFilter = bf;
    } else {
      /* Safari / Firefox: честной рефракции нет — матовое стекло */
      var fb = 'blur(' + (4 + blur).toFixed(1) + 'px) saturate(' + sat.toFixed(2) + ')';
      el.style.backdropFilter = fb; el.style.webkitBackdropFilter = fb;
    }
    el.style.background = 'rgba(255,255,255,' + (0.05 + F * 0.12).toFixed(3) + ')';
    el.style.boxShadow =
      'inset 1.5px 1.5px 1px rgba(255,255,255,' + (0.75 * L).toFixed(3) + '),' +
      'inset -1.5px -1.5px 1px rgba(255,255,255,' + (0.4 * L).toFixed(3) + '),' +
      'inset 0 0 ' + (6 + 20 * D).toFixed(1) + 'px rgba(255,255,255,' + (0.18 * L).toFixed(3) + '),' +
      '0 ' + (4 + 14 * D).toFixed(1) + 'px ' + (14 + 30 * D).toFixed(1) + 'px rgba(0,0,0,' + (0.10 + 0.14 * D).toFixed(3) + ')';
  };

  /* ---------- Strain: стекло тянется за пальцем и пружинит назад ---------- */
  function rubber(d) { var L = 80; return Math.sign(d) * L * (1 - Math.exp(-Math.abs(d) / L)); }
  Glass.prototype.bindStrain = function () {
    var self = this, el = this.el;
    el.style.touchAction = 'manipulation';
    el.addEventListener('pointerdown', function (e) {
      if (self.s.strain <= 0 || e.button > 0) return;
      var r = el.getBoundingClientRect();
      self.st = { sx: e.clientX, sy: e.clientY, bw: Math.max(r.width, 120), bh: Math.max(r.height, 48), x: 0, y: 0, vx: 0, vy: 0, id: e.pointerId, drag: true, moved: false };
      self.spring = false;
    });
    window.addEventListener('pointermove', function (e) {
      var st = self.st; if (!st || !st.drag || e.pointerId !== st.id) return;
      var k = self.s.strain / 100, dx = e.clientX - st.sx, dy = e.clientY - st.sy;
      if (!st.moved && Math.abs(dx) + Math.abs(dy) > 6) { st.moved = true; try { el.setPointerCapture(st.id); } catch (_) {} }
      if (st.moved) { st.x = rubber(dx) * k; st.y = rubber(dy) * k; self.paint(); }
    });
    function up() {
      var st = self.st; if (!st) return;
      st.drag = false; try { el.releasePointerCapture(st.id); } catch (_) {}
      if (st.moved) self.runSpring();
      else self.st = null;
    }
    window.addEventListener('pointerup', up); window.addEventListener('pointercancel', up);
  };
  Glass.prototype.paint = function () {
    var st = this.st, el = this.el, ax = Math.abs(st.x), ay = Math.abs(st.y);
    var sx = Math.max(0.75, 1 + 0.2 * ax / st.bw - 0.03 * ay / st.bh), sy = Math.max(0.75, 1 + 0.2 * ay / st.bh - 0.03 * ax / st.bw);
    el.style.translate = (st.x * 0.4).toFixed(2) + 'px ' + (st.y * 0.4).toFixed(2) + 'px';
    el.style.scale = sx.toFixed(4) + ' ' + sy.toFixed(4);
  };
  Glass.prototype.runSpring = function () {
    var self = this, st = this.st, last = performance.now();
    function tick(ts) {
      if (!self.st || self.st.drag) return;
      var dt = Math.min(0.032, (ts - last) / 1000 || 0.016); last = ts;
      var K = 460, C = 2 * 0.6 * Math.sqrt(K), n = 4, h = dt / n;
      for (var i = 0; i < n; i++) { st.vx += (-K * st.x - C * st.vx) * h; st.vy += (-K * st.y - C * st.vy) * h; st.x += st.vx * h; st.y += st.vy * h; }
      self.paint();
      if (Math.abs(st.x) + Math.abs(st.y) + Math.abs(st.vx) + Math.abs(st.vy) < 0.15) {
        self.el.style.translate = ''; self.el.style.scale = ''; self.st = null; return;
      }
      requestAnimationFrame(tick);
    }
    requestAnimationFrame(tick);
  };

  /* ---------- публичный API ---------- */
  function toList(t) {
    if (typeof t === 'string') return Array.prototype.slice.call(document.querySelectorAll(t));
    if (t && t.nodeType === 1) return [t];
    var out = [];
    Array.prototype.slice.call(t || []).forEach(function (x) { out = out.concat(toList(x)); });
    return out;
  }
  var LiquidGlass = {
    settings: KEYS.map(function (k) { return NAMES[k]; }),
    validate: validate,
    apply: function (target, settings) {
      validate(settings);                                   // без всех 7 настроек стекло не включится
      var list = toList(target).map(function (el) { return el._lg || (el._lg = new Glass(el, settings)); });
      list.forEach(function (g) { g.update(settings); });
      return list.length === 1 ? list[0] : list;
    }
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = LiquidGlass;
  root.LiquidGlass = LiquidGlass;
})(typeof window !== 'undefined' ? window : this);
